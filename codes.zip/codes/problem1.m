syms f(x)

% input: function f
f(x) = tanh(x);
df = diff(f,x); df5 = diff(f,x,5);

% input: point x0
x0 = 1;

% function Q
Q = @(h) (f(x0-2*h) - 8*f(x0-h) + 8*f(x0+h) - f(x0+2*h)) / (12*h);

% machine epsilon
epsilon = 1;
while (1+epsilon>1)
    epsilon = epsilon/2;
end
epsilon = epsilon*2;

% approximation error
error = @(h) abs(df(x0) - Q(h));

% plot error using different h
h = logspace(-16, 0, 200);
error_h = arrayfun(error, h);
loglog(h, error_h, 'linewidth', 4);
xlabel('value of h', 'fontsize', 15);
ylabel('error', 'fontsize', 15);

% the optimal h is roughly:
h_opt = h(find(error_h==min(error_h)))

% trade-off between roundoff error and truncation errors
h_opt_2 = double(15*epsilon*abs(f(x0))/2/abs(df5(x0)))^(1/5)