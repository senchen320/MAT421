#!/usr/bin/perl -w
#prime numbers less than N
use strict;
my $N = $ARGV[0];
my @num = (1) x $N;
for (my $i=2;$i<=sqrt($N);$i++) { 
	if($num[$i]==1){
		for(my $j=$i*$i;$j<=$N;$j+=$i){ $num[$j]=0; }
	}
}
for (my $i=2;$i<=$N;$i++){
	if ($num[$i]==1) { printf("%i ",$i);}}
printf("\n");
