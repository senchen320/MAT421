#!/usr/bin/perl -w
use strict;

my $file = "data.txt";
my $fmt = "%.16e\t%.16e\t%.16e\n"; # print format: 2 tab-separated numbers
open(BDW,">$file"); # open new file for writing, with handle/ref BDW
for (my $i=1;$i<=4;$i++){
	for (my $j=1;$j<=4;$j++){
		my $x = 1/8 + ($i-1)*1/4;
		my $y = 1/8 + ($j-1)*1/4;
		my $f = exp(-$x*$x - $y*$y);
		printf(BDW $fmt,$x,$y,$f);
	}
}
close BDW; # close file using handle

sub readAndCompute{
	my $errmsg = "Error: cannot open $file"; # define error message
	open(BDW,"<$file") or die($errmsg);

	my $sum = 0;
	while (<BDW>) { # read one line at a time
		chomp;
		my ($x,$y,$f) = split("\t",$_); # get $x and $y from the 2 fields
		$sum = $sum + $f
	}
	close BDW;

	printf("The approximation of intergral is %.16e\n", $sum/16);
}

readAndCompute();