% A:source, B:help, C:target
% initial state: all disks are in source peg.
X = ['A', 'A', 'A', 'A'];

Hanoi(X, length(X), 'A','C','B');
function x = Hanoi(x, n, source, target, help)
    if n > 0
        % move n-1 disks from source to help so they are out of the way
        x = Hanoi(x, n-1, source, help, target);
        % move the nth (largest) disk to target
        x(n) = target
        % move the n-1 disks on help to target
        x = Hanoi(x, n-1, help, target, source);
    end
end

